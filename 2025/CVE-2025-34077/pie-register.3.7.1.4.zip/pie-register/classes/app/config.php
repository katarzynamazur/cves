<?php
 
// Firebase API Key
define('PIE_APP_FIREBASE_API_KEY', get_option('pie_app_firebase_api_key'));